<template>
  <q-layout view="hHh lpR fFf">

    <q-header class="bg-primary text-white">
      <div class="bg-primary text-white col text-center text-weight-bold">
		<q-toolbar>
		<q-toolbar-title>TPC</q-toolbar-title>
		</q-toolbar>
		</div>
    </q-header>

    <q-page-container>
      <router-view />
    </q-page-container>

    <q-footer class="bg-grey-8 text-white">
      <q-toolbar>
        <q-toolbar-title>
         {{currentDateTime()}}
        </q-toolbar-title>
      </q-toolbar>
    </q-footer>

  </q-layout>
</template>
<script>
export default {
  methods: {
    currentDateTime() {
      const current = new Date();
      const date = current.getFullYear();
      const dateTime = date;

      return dateTime;
    }
  }
};
</script>