<template>
<q-responsive :ratio="1">
  <q-page class="flex flex-center">
        <q-card class="my-card">
      <q-item>
        <q-item-section avatar>
          <q-avatar>
            <img src="1632136586161.jpg">
          </q-avatar>
        </q-item-section>

        <q-item-section>
          <q-item-label>Cidade da Beira</q-item-label>
          <q-item-label caption>Abd Domingos</q-item-label>
        </q-item-section>

      </q-item>

      <img src="Beira.jpg" width="400" height="400">
    </q-card>
  </q-page>
  </q-responsive>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "PageIndex",
});
</script>
